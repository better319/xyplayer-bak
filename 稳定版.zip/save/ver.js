﻿document.writeln("<font color=\'#ff0000\'>3.6.5稳定版</font>");
